## Script for Exploratory Data Analysis exercises
## Compare Mean and Median for clay percent

library(soilDB)
library(ggplot2)

## Use loafercreek data from the soilDB package
## Create horizon object, make texture class a factor and
## summarize data for clay, ph, total coarse fragments and texture class

data("loafercreek")
h <- horizons(loafercreek) 

## plot qq line and linear fit line
qqnorm(h$clay, main='Percent Clay')
qqline(h$clay, col="red")

## Another qqplot option using the car package
## Dashed line indicates upper and lower values of 95% Confidence Interval

library(car)
qqPlot(h$clay, main='Percent Clay')

## Box plot of clay percent

boxplot(h$clay, ylab="Percent clay")


## received this error for the remaining lines
## Error in geom_qq_line() : could not find function "geom_qq_line"
#
#p_qq <- ggplot(h, aes(sample = clay)) + 
#  geom_qq() +
#  geom_qq_line() +
#  xlab("clay (%)") +
#  theme(aspect.ratio = 1) +
#  ggtitle("Q-Q Plot")
#
# box plot
#p_box <- ggplot(h, aes(x = 1, y = clay)) + 
#  geom_boxplot() +
#  ylab("clay (%)") +
#  theme(aspect.ratio = 1) +
#  coord_flip() +
#  ggtitle("Box Plot")
#
#gridExtra::grid.arrange(p_box, p_qq, ncol = 2)