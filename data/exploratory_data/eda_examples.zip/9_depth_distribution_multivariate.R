## Script for Exploratory Data Analysis exercises
## Distribution by depth of multiple variables

library(soilDB)
library(ggplot2)

## Use loafercreek data from the soilDB package
## slice data using aqp. This creates 1cm depth slices from horizon data

data("loafercreek")

## slice horizon data into 1 cm segment for first 100 cm for clay, ph and total coarse frag pct

s <- aqp::slice(loafercreek, 1:100 ~ clay + phfield + total_frags_pct)
s <- aqp::slab(s, fm = ~ clay + phfield + total_frags_pct, slab.fun = function(x) quantile(x, c(0.1, 0.5, 0.9), na.rm = TRUE))

##

names(s) <- gsub("\\.", "", names(s))
names(s) <- gsub("^X", "p", names(s))

## Create depth plot of clay, ph and frags with variance based on 10th and 90th percentiles 

ggplot(s, aes(x = top, y = p50)) +
  geom_line() +
  geom_ribbon(aes(ymin = p10, ymax = p90, x = top), alpha = 0.2) +
  xlim(c(100, 0)) + xlab("depth (cm)") + ylab("") +
  coord_flip() +
  facet_wrap(~ variable, scales = "free_x") +
  ggtitle("Loafercreek")




