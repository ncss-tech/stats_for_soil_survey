library(caret)
library(lattice)
library(Hmisc)
library(tables)
require (reshape2)
require (ggplot2)

### read csv that has null values for slope gradient

data <- read.table("VT_DSM_sample_NULL_data_points_utm_all_predictors.csv", sep=",", header=TRUE)  

### convert integer code to factor
data$soilid <- as.factor(data$soilid)

### summary to note presence of NA records
### doing a mean(data) would return NA

summary(data)
summary(data$SLP, na.rm=TRUE)

### summary by group using tables package

tabular(FEATURE ~ (SLP + WETM)*((n = 1) + mean + sd), data = data)

### this does not handle NA values so create a function of mean from the base R

Mean <- function(data) base::mean(data, na.rm=TRUE)
tabular(Mean ~SLP, data=data)

### create subset of cabot

cabot <- subset(data, FEATURE=="Cabot")

### populate null values using mean and median values, i.e. "impute" values

cabot$imputed_slpmean <- with(cabot, impute(SLP, mean))
cabot$imputed_slpmedian <- with(cabot, impute(SLP, median))

### create another dataframe with original slope values and imputed

cabotImputed <- cabot[c(1,5,13,14)]

### create a density plot of the three variables to visualize effects on distribution of NA, and imputed values
### the "wide" format dataframe needs to be converted to a "long" format to plot overlapping density plots

long = melt(cabotImputed, id.vars= "FEATURE")

### check central tendency of orig and imputed 

aggregate(long[, 3], list(long$variable), na.rm=TRUE, mean)
aggregate(long[, 3], list(long$variable), na.rm=TRUE, median)

p <- ggplot(aes(x=value, colour=variable), data=long)
p + geom_density()
