## Script for Exploratory Data Analysis exercises

library(soilDB)
library(ggplot2)

## Use loafercreek data from the soilDB package
## Create horizon object, make texture class a factor and
## summarize data for clay, ph, total coarse fragments and texture class

data("loafercreek")
h <- horizons(loafercreek) 
h$texture_class <- factor(h$texture_class)

vars <- c("clay", "phfield", "total_frags_pct", "texture_class")
summary(h[vars])