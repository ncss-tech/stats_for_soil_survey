## Script for Exploratory Data Analysis exercises
## Scatter plot of clay percent by depth

library(soilDB)
library(ggplot2)

## Use loafercreek data from the soilDB package
## Create horizon object, make texture class a factor and
## summarize data for clay, ph, total coarse fragments and texture class


data("loafercreek")

data("metadata")

# Create Generalized the horizon designations
n <- c("A",
       "BAt",
       "Bt1",
       "Bt2",
       "Cr",
       "R")
# REGEX rules
p <- c("A",
       "BA|AB",
       "Bt|Bw",
       "Bt3|Bt4|2B|C",
       "Cr",
       "R")

loafercreek$genhz <- generalize.hz(loafercreek$hzname, n, p)

h <- horizons(loafercreek)

h$genhz2 <- factor(h$genhz, levels = rev(levels(h$genhz)))

## set parameters for stacked bar chart

p_sb1 <- ggplot(h, aes(x = genhz2, fill = texture_class)) +
  geom_bar(position = "stack") +
  theme(aspect.ratio = 1) +
  ggtitle("Stacked Bars") +
  coord_flip()

## set parameters for proportional stacked bar chart

p_sb2 <- ggplot(h, aes(x = genhz2, fill = texture_class)) +
  geom_bar(position = "fill") +
  ylab("Proportion") +
  theme(aspect.ratio = 1) +
  ggtitle("Proportional Stacked Bars") + 
  coord_flip()

gridExtra::grid.arrange(p_sb1, p_sb2, ncol = 2)

## just plot the proportional stacked bar chart
gridExtra::grid.arrange(p_sb2, ncol = 1)
