#This code written by Colby Brungard to produce conditioned latin hypercube sampling points and similarity indecies across Black Mesa in San Juan County, UT, USA. 
	#10/15/2015

	# Colby Brungard, PhD
	# Researcher I 
	# Utah State University
	# Dept. of Plants, Soils and Climate
	# AgSci. 353
	# (435)-797-3404
	# 4820 Old Main Hill
	# Logan, UT. 84322-4820
	#  Envsoilco@gmail.com, Colby.Brungard@usu.edu

#install.packages('raster', dep = TRUE)
#install.packages('dismo', dep = TRUE)
#install.packages('clhs', dep = TRUE)
#install.packages('plotKML', dep = TRUE)

library(rgdal)
library(raster)
library(dismo)
library(clhs)
library(plotKML)

setwd("C:/GowersExample")
 tg <- Sys.time()

##########################################################################################################################################################################################
#Load and prepare data

#Study area Boundary
 BMBound <- readOGR(dsn = ".", layer = 'BlackMesa_KCN_110915')
 
 #Environmental Covariates.  
	wetindex             <- raster("./wetindesBM.tif")
	LS5_july11_BR53_utm  <- raster("./LS5_july11_BR53_utm_BM.tif")
 
 #Soil Survey data for Black Mesa. From Soil Survey of San Juan County Central Part
	#
	 bmSS <- readOGR(dsn = ".", layer = 'BlackMesaSoils')
	  bmsoils <- spTransform(bmSS, CRS("+proj=utm +zone=12 +ellps=GRS80 +towgs84=0,0,0,0,0,0,0 +units=m +no_defs")) #Reproject to match rasters
	    #Convert soil data from vector to raster format
		 #First, create a raster that will hold the rasterized soils data. This creates an "empty" raster
			 y <- raster(wetindex)
			#Rasterize the spatialpolygondataframe and make sure that it is a factor                                      
			 bmsoilsR <- rasterize(bmsoils, y, field = "MUSYM")

#---------------------------------------------------------------------------------------------------------------------------------------------------    
#Run the CLHS algorithm
#Create a raster stack of the input covariates
  cstak.bm <- stack(wetindex, LS5_july11_BR53_utm, bmsoilsR)
   names(cstak.bm)[3] <- 'bmsoils' #Give the soil data a better name!
  
#Mask the values outside the project area. This converts the values outside to NA.  
  bmmask1 <- crop(cstak.bm, BMBound) #crop to the only the area right around the study area boundary
  bmmask <- mask(bmmask1, BMBound) #This converts the factor to an integer and to a raster brick
  names(bmmask) <- c("wetindex", 'LS5_july11_BR53_utm', "bmsoilsR") #Give each raster a better name. 
 
#Convert to a spatial points dataframe. This has the benefit of getting rid of all of the NA values and allowing me to keep the xy coordinates of each cell. This takes 15 min or so. 
 bmmask.sp <- rasterToPoints(bmmask, spatial = T)

 #Force the soils data to be a factor
  bmmask.sp@data[[3]] <- as.factor(bmmask.sp@data[[3]])
 
 #Convert the spatial points data frame into a regular data frame 
  bmmask.sp.df <- as.data.frame(bmmask.sp)
  bmmask.sp.df1 <- bmmask.sp.df[complete.cases(bmmask.sp.df),] #remove NA values. keeps samples in the right places and reduces processing time. 

# Run cLHS
 set.seed(4801) #this makes the random number generator always start the same place. 
  bmsamp <- clhs(bmmask.sp.df1[,c(1:3)], size = 20, iter = 500, progress = T, simple = F) #Only a few iterations to make this example run fast. For actual use iter should be much larger
 
 #Plot objective functions to compare sampling and original covariate distributions. 
  pdf('./BlackMesa_cLHS.pdf', width = 14)
   plot(bmsamp, modes = c('obj', 'dens'))
  dev.off()

 #Get the XY coordinates at the sampling locations from the input data.  
  bmsamples <- bmmask.sp.df1[bmsamp$index_samples,]
 
 #Plot the coordinates to see if they make sense.
  plot(BMBound, main = "Black Mesa cLHS sampling locations")
  points(bmsamples[,c(4,5)], pch = 19, col = 'blue')
 
 
 #Write the data to a shapefile to give to field samplers. 
    #Make a spatialpointsdataframe with the correct spatial projection from the XY columns of the cLHS samples
     csamp.bm <- SpatialPointsDataFrame(coords = bmsamples[,c(4,5)], proj4string = CRS("+proj=utm +zone=12 +ellps=GRS80 +towgs84=0,0,0,0,0,0,0 +units=m +no_defs"), data = bmsamples[,c(1:3)])
	 #Give each CLHS point a logical name so that it is easy to import into a GPS
	  csamp.bm$ID <- paste(rep('BM',20), seq(1:20), sep = '') #The value '20' needs to be changed to match the number of cLHS points. BM stands for Black Mesa. Change if you want. 
	 #Write to shapefile
	  writeOGR(csamp.bm, "./cLHSsamples", "cLHSamples_BlackMesa", driver="ESRI Shapefile")
	  
	  #Write a KML file of the sampling points and put them in a folder called cLHSsamples. Not really necessary, but it is cool.
	   kml(csamp.bm, labels = ID, file.name = "./cLHSsamples/cLHSamples_BlackMesa.kml")


#--------------------------------------------------------------------------------------------------------
#Gowers similarity Index

#To run this similairty index on your own data, put in the appropriate object names in the following code and uncomment:
	#cstak.bm <- yourRasterStack #Raster stack of covariates input to cLHS. 
	#csamp <- yourCLHSample# SpatialPointsDataframe of the cLHS points


#****************************************************************************************************
#Calculate Gower's similarity index for every pixel within a 500 m radius buffer of each sampling point.
#1. First define the raster that will be used to hold the raster values
 r = bmmask[[1]] #Get a raster that is the same size as the covariates used. The easiest way is to just select the first covariate from the raster stack. 
 r[] <- NA #Since I took this from the first layer from raster stack make all the cell values NA. 
 names(r) <- 'Similarity' #Change the name.
 
#2. extract all pixels within 500 m of the sampling points. This returns a list, where each element in the list is a matrix. In this case buffer = 250 m, so final buffer will be 500 m in diameter. 
 buffs.bm <- extract(x = bmmask, y = csamp.bm, method = 'simple', buffer = 250, factors = TRUE, cellnumbers = TRUE)
	#x = the rasterstack to extract values from
	#y = spatialPointsDataFrame of the cLHS locations
	#buffer = size (in m) of the buffer 
	#factors = keeps the right values associated with the factor covariates
	#cellnumbers = this returns the cell numbers which eventually allows you to make a raster. It is very important. 


#3.Apply gowers similarity index to each element of list of extracted raster values.
	#Get the cell numbers from each cLHS point. This will be used to identity the appropriate column in the similarity matrix. 
	 cLHS_cellNums <- extract(x = bmmask, y = csamp.bm, method = 'simple', cellnumbers = TRUE, small = TRUE)
	 cCellnum <- cLHS_cellNums[,1] #just need the cell numbers. 
	 

#3.b Function to calculate Gower's similarity index around each point. I used Gower's because it can handle categorical covariates, but there are other options. 
 library(cluster)

#Define a list to hold the data.   
	 similarL <- list()
 
 #The actual function. This takes about 4 min to run on a Xenon 3.6 ghZ processor
  for(i in seq(buffs.bm)){
	  
	 testL <- data.frame(buffs.bm[[i]]) #convert each list element in buffs to a data frame
	 testL <- testL[complete.cases(testL),] #remove NA values. If values are on edges this makes the elements of similarL not the same so they can't be rbind-ed together
		testL[,3] <- as.factor(testL[,3]) #Force any factors to be a factor
	 
	 GtestL <- daisy(x = testL[,-1], metric = 'gower') #Calculate gowers similarity index for each list element.
	 gmatL <- cbind(testL$cell, as.matrix(GtestL)) #Convert dissimilarity objects to matrix.
	 
	 finalgL <- 1-gmatL[gmatL[,1] == cCellnum[i],] #select the row of similarity indices with cell numbers equal to the cell number of the cLHS point, then convert from dissimilarity to similarity by subtracting from 1.
	 
	 similarL[[i]] <- cbind(testL$cell, finalgL[-1]) #combine the cellnumbers of the raster to the similarity index. 
	 
	 #Print out the iteration number that it is currently working on. 
	  cat("Iteration: ", i, "  | ",date(), "\n")
	  flush.console()
	  
#Note this returns several warning messages from the daisy package. See https://stat.ethz.ch/R-manual/R-devel/library/cluster/html/daisy.html for more information on these warnings.
  }

s.df <- do.call(rbind.data.frame, similarL) #Convert list of cell numbers and similarity values to a dataframe
 names(s.df) <- c('CellNum', 'Similar') #Give better names

#Index the original raster by the cell numbers and replace the NA values with the similarity values. This results in a raster with similarity values in the buffers around each cLHS point and NA everywhere else. 
 r[s.df$CellNum] <- s.df$Similar #This takes 1 min.
	 
plot(r) #you can't really see much with this plot and need to write the raster for viewing in a GIS.  
 writeRaster(r, filename = "SimilarityIndex_BlackMesa.tif")


#*********************** 
#*****AlternativeSamplingAreas
#***********************

#Select all raster cells that have similarity values similar to the original cLHS point and write this to file. Knowing exactly where samples can be moved is better than just knowing similarity values. 
# A few thoughts on this calculation:
# The threshold similarity values are important and seemingly small differences (e.g., 0.7 vs. 0.75) make a big difference. 
#I initially tried using a standard similarity threshold of 0.8, but that resulted in an empty raster because threshold values were <0.8. I finally decided on the threshold values by looking at the similarity index values around each point.
#Although 0.65 seems low, these return areas that are physically consistent with the cLHS sampling point as judged by air photo investigation. I think that having more input covariates results in higher similarity values, or it could just be that flat areas (like Black Mesa) have less siilar surrounding areas than do study areas with more topographic relief (like I saw in the Maine study with Jamin). 
 

#Load Similarity Index and give correct projection
 BMsim <- raster("./SimilarityIndex_BlackMesa.tif")
  projection(BMsim) <- "+proj=utm +zone=12 +datum=NAD83 +units=m +no_defs +ellps=GRS80 +towgs84=0,0,0"

#Choose all areas with similarity values >= a threshold and write to raster
 BMsimThres <- BMsim >= 0.65 #Change threshold 0.65 if needed 
  plot(BMsimThres)
  writeRaster(BMsimThres, "./PermissibleAlternativeSamplingAreas_BlackMesa.tif")
 
save.image("./cLHS_GowersSimilarity.RData")

	 tg2 <- Sys.time()
	 print(tg2-tg) #
